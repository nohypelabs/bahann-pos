| function | decision | finding | recommended_action |
| --- | --- | --- | --- |
| cleanup_expired_refresh_tokens | KEEP WITH HARDENING | SECURITY DEFINER; deletes expired/revoked/used tokens | Set search_path explicitly; ensure only scheduler/service role can execute |
| create_income_from_sale | DROP OR REWRITE | References financial_transactions, NEW.transaction_number, sales_transaction_seq, not aligned with current transactions.transaction_id | Remove if unused; rewrite only after financial module schema exists |
| generate_transaction_number | DROP OR REWRITE | Writes NEW.transaction_number; current transactions uses transaction_id | Replace with explicit transaction_id generator in app/server function |
| get_daily_expense_summary | KEEP WITH TENANT SCOPE | Currently p_outlet_id only, no tenant enforcement | Add tenant_id and permission/outlet guard |
| get_sales_summary | REWRITE BEFORE PRODUCTION | SECURITY DEFINER and trusts p_outlet_ids input | Enforce user outlet access inside function or remove SECURITY DEFINER |
| get_sales_trend | REWRITE BEFORE PRODUCTION | SECURITY DEFINER and trusts p_outlet_ids input | Enforce user outlet access inside function or remove SECURITY DEFINER |
| get_top_products | REWRITE BEFORE PRODUCTION | SECURITY DEFINER and trusts p_outlet_ids input | Enforce user outlet access inside function or remove SECURITY DEFINER |
| update_product_stock | DROP OR REWRITE | References NEW.type and products.stock/updated_at; schema has stock_movements.movement_type and no products.stock | Replace with inventory_movements ledger + materialized stock summary |
| update_updated_at_column | KEEP | Generic timestamp trigger helper | OK |
| update_expenses_updated_at | KEEP | Operational expenses updated_at helper | OK |
| update_password_reset_tokens_updated_at | KEEP | Token updated_at helper | OK but token table backend-only |
