| area | finding | severity | recommended_action |
| --- | --- | --- | --- |
| tenant indexes | Missing because tenant_id missing | CRITICAL | After tenant_id migration add indexes: tenant_id, (tenant_id,outlet_id), (tenant_id,created_at) |
| transactions_transaction_id_key | Global unique transaction_id | MEDIUM | Change future unique to (tenant_id, transaction_id) or sequence namespaced per tenant/outlet |
| products_sku_key + products_sku_owner_id_unique | Conflicting global SKU unique and owner-scoped SKU unique | HIGH | Drop global products_sku_key after safe migration; use (tenant_id, sku) unique |
| outlets_name_key | Global unique outlet name | MEDIUM-HIGH | Change to unique (tenant_id, name) |
| payment_methods_code_key | Global code unique | MEDIUM | Use system-wide code if intended; otherwise tenant-scoped method config |
| qris_config_merchant_id_key | Global merchant ID unique | LOW-MEDIUM | OK if merchant ID globally unique; still add tenant/outlet owner context |
| cash active shift guard | Missing | HIGH | Add partial unique index on opened_by/outlet_id where status in open/submitted/pending_approval |
