| area | target | current | severity | action |
| --- | --- | --- | --- | --- |
| Tenant isolation | tenants table + tenant_id across core tables | No tenants table; owner_id/user_id scoping | CRITICAL | Add tenants; backfill; scope queries by tenant_id |
| Role model | roles + permissions + role_permissions | users.role string + users.permissions jsonb | CRITICAL | Migrate to RBAC tables; keep legacy fields during transition |
| User outlet access | user_role_assignments scope TENANT/OUTLET/OUTLET_GROUP | users.outlet_id single outlet | CRITICAL | Create assignment table; allow one user many scopes |
| Area manager | outlet_groups + outlet_group_members | Missing | HIGH | Add group model before UI needs it |
| Cashier login | employee_code + pin_hash optional email | email required, password_hash only | MEDIUM-HIGH | Add employee_code, username, pin_hash, status |
| Device scoping | pos_devices + assignments | Missing | HIGH | Bind POS device to outlet and include device_id in shift/transactions |
| Approval workflow | transaction_approvals | Missing | HIGH | Add request/approve/reject workflow |
| Audit immutability | trigger prevents UPDATE/DELETE | Missing | HIGH | Add immutable audit trigger and revoke client writes |
| Cash closing | server-side expected snapshot + generated difference | expected_cash/difference writable | HIGH | Compute expected cash server-side; use snapshot |
