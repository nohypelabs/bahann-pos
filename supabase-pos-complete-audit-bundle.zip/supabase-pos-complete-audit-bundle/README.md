# Supabase POS Complete Audit Bundle

Ini bundle final audit untuk schema Supabase POS saat ini terhadap target POS multi-tenant 28 outlet.

## Baca dulu

1. `01-COMPLETE-AUDIT-REPORT.md` — laporan utama.
2. `patches/00-emergency-security-patch.sql` — patch security urgent, wajib dites di staging.
3. `02-MIGRATION-ROADMAP.md` — urutan migrasi aman.
4. `matrices/*.csv` — matrix teknis per table, RLS, RBAC, function, index.
5. `tests/*.md` — test plan setelah patch/migrasi.
6. `prompts/ai-cli-implementation-prompt.md` — prompt siap pakai untuk AI CLI.

## Status

- Current schema: diagnostic complete.
- Migration SQL: template/patch plan, bukan disuruh blindly run di production.
- Priority pertama: RLS/grants/token table lockdown.

## Safety

Raw files dari audit disertakan di `raw/db-audit/`. Jangan upload file ini ke publik kalau ada perubahan dump yang mengandung data/secrets di masa depan. Bundle sekarang dibuat dari DDL/audit files yang lu kirim, bukan row data produksi.
