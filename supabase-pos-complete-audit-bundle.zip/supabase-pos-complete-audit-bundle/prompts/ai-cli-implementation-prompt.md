# AI CLI Implementation Prompt

You are working on a Supabase/PostgreSQL POS database. Implement changes safely and phase-by-phase.

Rules:
- Do not run destructive migrations without a rollback.
- Do not drop legacy columns in early phases.
- Never expose secrets.
- Run all changes on staging first.
- Every migration must include verification queries.
- All sensitive changes must be tested with anon, authenticated, and service role contexts.

Read these files first:

```txt
01-COMPLETE-AUDIT-REPORT.md
02-MIGRATION-ROADMAP.md
03-ROLLBACK-PLAN.md
matrices/01-table-by-table-risk-matrix.csv
patches/00-emergency-security-patch.sql
tests/rls-security-test-plan.md
tests/acceptance-checklist.md
raw/db-audit/schema-public.sql
raw/db-audit/rls-status.txt
raw/db-audit/policies.txt
raw/db-audit/grants.txt
raw/db-audit/functions.sql
```

Task order:

1. Apply Phase 0 emergency security patch in staging only.
2. Run RLS/security tests.
3. Report failures before continuing.
4. Create tenant foundation migration.
5. Backfill default tenant.
6. Add RBAC tables and seed roles/permissions.
7. Migrate legacy users.role/outlet_id to user_role_assignments.
8. Add outlet groups for future Area Manager.
9. Add POS devices and assignments.
10. Add transaction_approvals.
11. Add cash session hardening fields.
12. Update policies and server guards.
13. Rerun acceptance checklist.

Hard requirements:

- All core queries must scope by tenant_id.
- All outlet access must be server-side validated.
- No paid transaction may be hard-deleted.
- All sensitive actions must write audit_logs.
- Audit logs must be immutable.
- Token tables must be backend-only.
- expected_cash must never be accepted from client input.

Output:
- Migration files.
- Verification SQL.
- Test result summary.
- Any breaking changes found.
