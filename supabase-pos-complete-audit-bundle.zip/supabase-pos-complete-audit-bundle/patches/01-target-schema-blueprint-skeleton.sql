-- 01-target-schema-blueprint-skeleton.sql
-- This is a design skeleton, not a direct production migration.
-- Validate with existing data and write real migrations phase-by-phase.

-- TENANT FOUNDATION
create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- RBAC FOUNDATION
create table if not exists public.roles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.tenants(id),
  key text not null,
  name text not null,
  description text,
  is_system boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.permissions (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  description text
);

create table if not exists public.role_permissions (
  role_id uuid not null references public.roles(id) on delete cascade,
  permission_id uuid not null references public.permissions(id) on delete cascade,
  primary key(role_id, permission_id)
);

create table if not exists public.outlet_groups (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  name text not null,
  description text,
  created_at timestamptz not null default now(),
  unique(tenant_id, name)
);

create table if not exists public.outlet_group_members (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  outlet_group_id uuid not null references public.outlet_groups(id) on delete cascade,
  outlet_id uuid not null references public.outlets(id) on delete cascade,
  unique(outlet_group_id, outlet_id)
);

create table if not exists public.user_role_assignments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id),
  role_id uuid not null references public.roles(id),
  scope_type text not null check (scope_type in ('TENANT','OUTLET','OUTLET_GROUP')),
  outlet_id uuid references public.outlets(id),
  outlet_group_id uuid references public.outlet_groups(id),
  created_at timestamptz not null default now()
);

create unique index if not exists idx_ura_unique_tenant_scope
  on public.user_role_assignments(user_id, role_id, scope_type)
  where scope_type = 'TENANT';

create unique index if not exists idx_ura_unique_outlet_scope
  on public.user_role_assignments(user_id, role_id, scope_type, outlet_id)
  where scope_type = 'OUTLET';

create unique index if not exists idx_ura_unique_outlet_group_scope
  on public.user_role_assignments(user_id, role_id, scope_type, outlet_group_id)
  where scope_type = 'OUTLET_GROUP';

-- POS DEVICE FOUNDATION
create table if not exists public.pos_devices (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  device_code text not null,
  name text,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  unique(tenant_id, device_code)
);

create table if not exists public.pos_device_assignments (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  device_id uuid not null references public.pos_devices(id),
  outlet_id uuid not null references public.outlets(id),
  assigned_by uuid references public.users(id),
  assigned_at timestamptz not null default now(),
  revoked_at timestamptz,
  revoke_reason text
);

create unique index if not exists idx_one_active_device_assignment
  on public.pos_device_assignments(device_id)
  where revoked_at is null;

-- APPROVAL WORKFLOW
create table if not exists public.transaction_approvals (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id),
  outlet_id uuid not null references public.outlets(id),
  transaction_id uuid references public.transactions(id),
  shift_id uuid references public.cash_sessions(id),
  device_id uuid references public.pos_devices(id),
  type text not null check (type in ('void','refund','discount_override','cash_drawer_open','stock_adjustment','shift_close_exception')),
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired')),
  amount numeric(15,2),
  requested_by uuid not null references public.users(id),
  requested_at timestamptz not null default now(),
  request_reason text not null,
  approved_by uuid references public.users(id),
  approved_at timestamptz,
  approver_note text,
  expires_at timestamptz
);
