-- 00-emergency-security-patch.sql
-- Purpose: lock immediate Supabase RLS/grants/token exposure risks.
-- Run on STAGING first. Review app routes before production.

begin;

-- 1) Enable RLS on tables currently reported as RLS OFF.
alter table public.bank_accounts enable row level security;
alter table public.payment_confirmations enable row level security;
alter table public.payment_methods enable row level security;
alter table public.payments enable row level security;
alter table public.qris_config enable row level security;
alter table public.wa_templates enable row level security;

-- 2) Revoke broad client grants from sensitive/backend-only tables.
-- service_role bypasses RLS by design in Supabase; backend should use service role for admin-only operations.
revoke all on table public.bank_accounts from anon, authenticated;
revoke all on table public.payment_confirmations from anon, authenticated;
revoke all on table public.payment_methods from anon, authenticated;
revoke all on table public.payments from anon, authenticated;
revoke all on table public.qris_config from anon, authenticated;
revoke all on table public.wa_templates from anon, authenticated;
revoke all on table public.password_reset_tokens from anon, authenticated;
revoke all on table public.refresh_tokens from anon, authenticated;
revoke all on table public._migrations from anon, authenticated;
revoke all on table public.platform_settings from anon, authenticated;

-- 3) Drop overly broad token policies if they exist.
drop policy if exists "Backend can manage password reset tokens" on public.password_reset_tokens;
drop policy if exists "System can insert refresh tokens" on public.refresh_tokens;
drop policy if exists "System can update refresh tokens" on public.refresh_tokens;

-- Optional: keep users able to delete/read only their own refresh token only if app explicitly needs client-side token management.
-- Recommended: manage refresh_tokens from backend only.
-- drop policy if exists "Users can read own refresh tokens" on public.refresh_tokens;
-- drop policy if exists "Users can delete own refresh tokens" on public.refresh_tokens;

-- 4) Audit logs should not be mutable.
create or replace function public.prevent_audit_log_mutation()
returns trigger
language plpgsql
as $$
begin
  raise exception 'audit_logs are immutable';
end;
$$;

drop trigger if exists trg_audit_logs_no_update_delete on public.audit_logs;
create trigger trg_audit_logs_no_update_delete
before update or delete on public.audit_logs
for each row execute function public.prevent_audit_log_mutation();

-- 5) Revoke direct update/delete on audit_logs from client roles.
revoke update, delete, truncate on table public.audit_logs from anon, authenticated;

commit;

-- Post-checks:
-- select tablename, rowsecurity from pg_tables where schemaname='public' order by tablename;
-- select * from pg_policies where schemaname='public' order by tablename, policyname;
