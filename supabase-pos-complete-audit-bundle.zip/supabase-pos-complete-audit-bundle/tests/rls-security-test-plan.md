# RLS Security Test Plan

Run these tests in staging after `00-emergency-security-patch.sql`.

## Test users

Prepare:
- anon client
- authenticated cashier user
- authenticated store manager user
- authenticated tenant admin user
- service role backend client

## Tests

### 1. Anon exposure

Using anon key, verify these fail:

```txt
SELECT/INSERT/UPDATE/DELETE bank_accounts
SELECT/INSERT/UPDATE/DELETE payment_methods
SELECT/INSERT/UPDATE/DELETE payments
SELECT/INSERT/UPDATE/DELETE qris_config
SELECT/INSERT/UPDATE/DELETE wa_templates
SELECT/INSERT/UPDATE/DELETE password_reset_tokens
SELECT/INSERT/UPDATE/DELETE refresh_tokens
```

Expected: denied.

### 2. Authenticated cashier exposure

Cashier must not:
- read global payment config unless explicitly published by backend endpoint
- read password_reset_tokens or refresh_tokens
- update audit_logs
- read another outlet's transactions after tenant/RBAC migration

### 3. Service role

Service role backend should still be able to:
- create password reset token
- manage refresh token
- create payment confirmation
- insert audit log

### 4. Audit log immutability

Try:
```sql
update public.audit_logs set action = 'tampered' where id = '<some-id>';
delete from public.audit_logs where id = '<some-id>';
```
Expected: trigger raises `audit_logs are immutable`.

### 5. Negative tests after RBAC migration

- Store manager outlet A cannot approve refund outlet B.
- Cashier cannot call refund approve.
- Area manager group A cannot see group B.
- Tenant admin A cannot see tenant B.
