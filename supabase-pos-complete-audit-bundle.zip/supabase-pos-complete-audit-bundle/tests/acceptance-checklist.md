# Acceptance Checklist

## Phase 0 Security

- [ ] RLS ON for all sensitive payment/config tables.
- [ ] anon cannot read/write payment/config/token tables.
- [ ] authenticated cannot read/write token tables.
- [ ] audit_logs cannot be updated/deleted.
- [ ] App still works through intended backend endpoints.

## Tenant foundation

- [ ] All core rows have tenant_id.
- [ ] No core table has NULL tenant_id after backfill.
- [ ] Tenant indexes exist.
- [ ] Cross-tenant query tests fail.

## RBAC

- [ ] roles seeded.
- [ ] permissions seeded.
- [ ] role_permissions seeded.
- [ ] user_role_assignments populated from legacy users.role/outlet_id.
- [ ] get_user_outlet_ids works for TENANT/OUTLET/OUTLET_GROUP.
- [ ] user_has_permission works by role and scope.

## POS operations

- [ ] Device is assigned to exactly one active outlet.
- [ ] Kasir cannot choose arbitrary outlet.
- [ ] Open shift requires device/outlet context.
- [ ] Transaction stores tenant_id, outlet_id, cashier_user_id, shift_id, device_id.
- [ ] Refund/void requires approval.
- [ ] Closing shift expected cash computed server-side.

## Reporting

- [ ] Admin tenant sees all outlets in tenant only.
- [ ] Area manager sees assigned group only.
- [ ] Store manager sees assigned outlet only.
- [ ] Cashier sees own shift only.
- [ ] Export report writes audit log.
