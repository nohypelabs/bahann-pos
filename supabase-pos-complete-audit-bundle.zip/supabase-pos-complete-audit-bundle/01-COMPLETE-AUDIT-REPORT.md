# Supabase POS Complete Schema Audit Bundle

**Generated:** 2026-06-17 03:56:32 Asia/Jakarta-ish runtime  
**Input bundle:** `db-audit.zip` + `database.types.ts` + POS multi-tenant README/audit notes  
**Target:** POS multi-tenant untuk 1 tenant 28 outlet, tenant admin global, kepala toko outlet-scoped, kasir shift-scoped, area manager future-ready.

## 0. Verdict

**Current score for the target architecture: 3.8/10.**

Current database is closer to:

```txt
single-owner / owner-scoped POS
+ outlet basic
+ transaction basic
+ cash session basic
+ payment basic
+ audit log basic
+ partial RLS setup
```

Target database should become:

```txt
multi-tenant POS SaaS
+ tenant_id isolation everywhere
+ RBAC with scoped assignments
+ outlet groups for Area Manager
+ device-bound POS
+ shift cash reconciliation with server-side snapshot
+ approval workflow for void/refund/discount override
+ immutable audit logs
+ tenant/outlet/device/shift scoped reports
```

The current schema is not useless. It is a workable legacy base. But forcing it into 28-outlet multi-tenant operations with only `users.role` and `users.outlet_id` would be the database equivalent of tying a truck with raffia string. Charming, if you enjoy incident reports.

## 1. Evidence inventory

The audit used these extracted files:

| File | Use |
|---|---|
| `schema-public.sql` | tables and columns |
| `rls-status.txt` | RLS enabled/disabled per table |
| `policies.txt` | RLS policy definitions |
| `grants.txt` | table grants for anon/authenticated/postgres/service_role |
| `indexes.txt` | primary, unique, and custom indexes |
| `constraints.txt` | unique and check constraints |
| `foreign-keys.txt` | relationship map |
| `functions.sql` | function DDL |
| `triggers.txt` | active triggers |
| `views.txt` | view definitions |
| `migrations.txt` | migration file list |
| `database.types.ts` | Supabase generated TS surface |

All raw evidence is included inside `/raw/db-audit/`.

## 2. Executive findings

### Critical

1. **No proper tenant model.** There is no `tenants` table and no `tenant_id` in core tables. Current schema uses `owner_id`, `user_id`, and `outlet_id` as partial ownership proxies.
2. **RLS is OFF on payment/config tables.** Tables without RLS: `bank_accounts, payment_confirmations, payment_methods, payments, qris_config, wa_templates`.
3. **All public tables appear granted broad privileges to anon/authenticated.** With RLS OFF, those grants become direct exposure risk.
4. **Token tables are too public-facing.** `password_reset_tokens` has `ALL true/true`; `refresh_tokens` has broad insert/update policies and client-visible grants.
5. **RBAC is legacy.** `users.role`, `users.permissions`, and `users.outlet_id` cannot support tenant admin + area manager + multi-outlet assignments cleanly.
6. **Audit logs are not immutable and not tenant/outlet/device/shift scoped.** The audit table exists, but it is not strong enough for production investigation.
7. **Cash reconciliation fields are writable.** `expected_cash`, `difference`, and sales totals in `cash_sessions` are stored as mutable fields.

### High

1. No `pos_devices` or device assignment model.
2. No `transaction_approvals` workflow table.
3. No `shift_id`/`device_id` on transactions.
4. Products, payment methods, QRIS, bank accounts, and promotions are not tenant-scoped.
5. Functions include stale helpers referencing non-existent/currently mismatched structures.
6. Most RLS-enabled core tables have no policies, which likely blocks client access but is not an intentional policy design.

## 3. Current RLS posture

| Category | Tables | Meaning |
|---|---:|---|
| RLS enabled | 20 | Safer by default, but many have no policy |
| RLS disabled | 6 | Critical if table has anon/auth grants |
| Policies defined | 12 policies over 5 tables | Sparse policy coverage |

Tables with **RLS OFF**:

```txt
- bank_accounts
- payment_confirmations
- payment_methods
- payments
- qris_config
- wa_templates
```

Tables with **RLS ON but no policy** are likely deny-by-default from Supabase client. That is safer than exposure, but it also means features may silently rely on service role or fail in client mode. This needs intentional design, not lucky confusion wearing a security hat.

## 4. RLS/policy/grants interpretation

The grants dump shows `anon` and `authenticated` have table privileges across public tables. In PostgreSQL/Supabase, **RLS policies still apply when RLS is ON**, so broad grants are less dangerous there. But where **RLS is OFF**, those grants can expose full table operations.

Immediate concern tables:

```txt
bank_accounts
payment_confirmations
payment_methods
payments
qris_config
wa_templates
```

Token tables:

```txt
password_reset_tokens
refresh_tokens
```

These should be backend-only. Client-side access to password reset or refresh token tables is one of those decisions that makes future incident writeups write themselves.

## 5. Current schema vs target blueprint

| Area | Current | Target | Severity |
|---|---|---|---|
| Tenant | No `tenants`, no `tenant_id` | `tenants` + `tenant_id` everywhere core | Critical |
| Outlet | `outlets.owner_id` | `outlets.tenant_id` + ownership/users via RBAC | Critical |
| Users | `role`, `permissions jsonb`, `outlet_id` | `roles`, `permissions`, `user_role_assignments` | Critical |
| Area manager | Missing | `outlet_groups`, `outlet_group_members` | High |
| Cashier login | Email/password | employee_code/PIN optional email | Medium-High |
| Device POS | Missing | `pos_devices`, `pos_device_assignments` | High |
| Transactions | basic sale/void/refund fields | tenant/outlet/shift/device/user/approval scoped | Critical |
| Cash sessions | mutable expected/difference totals | server-side expected snapshot + approval status | High |
| Approval | Missing | `transaction_approvals` | High |
| Audit log | exists but weak | immutable + scoped + metadata | High |
| Inventory | `stock_movements` exists but no tenant/approval | movement ledger tenant-scoped | Medium-High |
| Payment config | global | tenant/outlet scoped | High |

## 6. Table-by-table audit summary

See `/matrices/01-table-by-table-risk-matrix.csv` for the full version.

Top issues:

- `users`: critical legacy authorization model.
- `outlets`: critical missing tenant foundation.
- `transactions`: critical missing tenant/shift/device/approval context.
- `payments`, `payment_methods`, `bank_accounts`, `qris_config`, `payment_confirmations`, `wa_templates`: critical RLS OFF exposure.
- `cash_sessions`: high risk cash reconciliation mutability.
- `audit_logs`: high risk mutability and insufficient operational context.

## 7. Function and trigger audit

Active triggers:

```txt
trigger_name           | event_manipulation |  event_object_table   |                      action_statement                      | action_timing 
----------------------------------+--------------------+-----------------------+------------------------------------------------------------+---------------
 trigger_expenses_updated_at      | UPDATE             | operational_expenses  | EXECUTE FUNCTION update_expenses_updated_at()              | BEFORE
 password_reset_tokens_updated_at | UPDATE             | password_reset_tokens | EXECUTE FUNCTION update_password_reset_tokens_updated_at() | BEFORE
 update_transactions_updated_at   | UPDATE             | transactions          | EXECUTE FUNCTION update_updated_at_column()                | BEFORE
(3 rows)
```

Important function decisions:

| Function | Decision | Why |
|---|---|---|
| `cleanup_expired_refresh_tokens` | Keep with hardening | SECURITY DEFINER, set `search_path`, backend only |
| `create_income_from_sale` | Drop/rewrite | References mismatched financial schema and `transaction_number` |
| `generate_transaction_number` | Drop/rewrite | Current table uses `transaction_id`, not `transaction_number` |
| `get_sales_summary` | Rewrite | SECURITY DEFINER trusts `p_outlet_ids` input |
| `get_sales_trend` | Rewrite | Same risk |
| `get_top_products` | Rewrite | Same risk |
| `update_product_stock` | Drop/rewrite | References `NEW.type` and `products.stock`; not aligned with current stock model |

Full matrix: `/matrices/04-function-trigger-audit.csv`.

## 8. Emergency patch priority

Before full migration, patch security posture:

1. Enable RLS on RLS-off sensitive tables.
2. Revoke broad client grants from backend-only/sensitive config/token tables.
3. Remove or replace public `true` token policies.
4. Add immutability trigger to `audit_logs`.
5. Test with anon key and authenticated test user.

Patch template: `/patches/00-emergency-security-patch.sql`.

## 9. Migration phases

### Phase 0: Emergency security

No schema rewrite yet. Just lock exposure.

### Phase 1: Tenant foundation

Create `tenants`, backfill default tenant, add `tenant_id` to core tables, add indexes. Do this before RBAC; otherwise every policy function becomes temporary garbage.

### Phase 2: RBAC and scoping

Create:

```txt
roles
permissions
role_permissions
user_role_assignments
```

Then migrate legacy `users.role` into assignments.

### Phase 3: Area Manager

Create:

```txt
outlet_groups
outlet_group_members
```

Add `OUTLET_GROUP` scope.

### Phase 4: POS device and shift hardening

Create device assignment model and add `device_id` to shift/transaction.

### Phase 5: Approval workflow

Create `transaction_approvals` and route refund/void/discount override through request -> approve/reject.

### Phase 6: Cash and reporting hardening

Use `expected_cash_snapshot`, `actual_cash`, and generated/view-based difference. Lock shift close flow.

### Phase 7: Inventory/reporting cleanup

Make `stock_movements` tenant-scoped, add references and approvals, treat daily tables as summaries.

## 10. Testing strategy

See `/tests/rls-security-test-plan.md` and `/tests/acceptance-checklist.md`.

Minimum tests:

- Anon cannot read/write payment/config/token tables.
- Authenticated cashier cannot read another outlet.
- Store manager can approve only assigned outlet actions.
- Admin tenant can report all outlets in tenant only.
- Area manager can access only outlet group.
- Audit log cannot be updated/deleted.
- Expected cash cannot be client-supplied.
- Paid transactions cannot be hard-deleted.

## 11. Final recommendation

Do not run the full multi-tenant migration in one giant heroic script. Heroic scripts are how database people develop trust issues.

Recommended order:

```txt
1. Apply emergency RLS/grant patch in staging.
2. Run security tests with anon/authenticated/service role.
3. Add tenant foundation and backfill.
4. Add RBAC tables while keeping legacy fields.
5. Switch app guards to RBAC functions.
6. Add POS device + approval workflow.
7. Remove legacy fields only after production parity tests.
```

## 12. Bundle map

```txt
README.md
01-COMPLETE-AUDIT-REPORT.md
02-MIGRATION-ROADMAP.md
03-ROLLBACK-PLAN.md
matrices/*.csv
patches/*.sql
prompts/*.md
tests/*.md
raw/db-audit/*
reference/*
```
