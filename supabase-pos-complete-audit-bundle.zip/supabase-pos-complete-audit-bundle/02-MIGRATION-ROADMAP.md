# Migration Roadmap v1

## Goal

Menaikkan schema dari owner-scoped POS ke multi-tenant POS dengan RBAC + outlet scoping + device-bound POS.

## Rule utama

Jangan hapus legacy columns di awal. Tambahkan struktur baru, backfill, aktifkan guard, lalu deprecate legacy fields. Database suka drama kalau diajak lompat jauh tanpa pemanasan.

## Phase 0 — Emergency Security Patch

Scope:
- Enable RLS untuk tabel RLS OFF.
- Revoke client grants dari payment/config/token/backend-only tables.
- Replace public token policies.
- Add audit log immutability.

Deliverable:
- `patches/00-emergency-security-patch.sql`
- Passing tests from `tests/rls-security-test-plan.md`

## Phase 1 — Tenant Foundation

Create:
```sql
tenants(id, name, slug, status, created_at, updated_at)
```

Add `tenant_id` to:
```txt
outlets, users, products, transactions, transaction_items, cash_sessions,
payments, payment_methods, bank_accounts, qris_config, promotions,
audit_logs, daily_sales, daily_stock, stock_alerts, stock_movements,
operational_expenses, payment_confirmations
```

Backfill strategy:
1. Create default tenant from current owner/business.
2. Set `outlets.tenant_id` from current `outlets.owner_id` ownership mapping.
3. Propagate tenant_id through FK chains.
4. Add NOT NULL after validation.
5. Add tenant indexes.

## Phase 2 — RBAC Foundation

Create:
```txt
roles
permissions
role_permissions
user_role_assignments
```

Support scopes:
```txt
TENANT
OUTLET
OUTLET_GROUP
```

Keep `users.role`, `users.permissions`, and `users.outlet_id` as legacy until app migration finishes.

## Phase 3 — Area Manager

Create:
```txt
outlet_groups
outlet_group_members
```

Area manager access:
```txt
role = AREA_MANAGER
scope_type = OUTLET_GROUP
```

## Phase 4 — POS Device Binding

Create:
```txt
pos_devices
pos_device_assignments
```

Add `device_id` to:
```txt
cash_sessions
transactions
audit_logs
transaction_approvals
```

## Phase 5 — Approval Workflow

Create:
```txt
transaction_approvals
```

Actions covered:
```txt
void
refund
discount_override
cash_drawer_open
stock_adjustment
shift_close_exception
```

## Phase 6 — Cash Session Hardening

Add:
```txt
expected_cash_snapshot
cash_in
cash_out
submitted_at
approved_by
approved_at
rejected_by
rejected_at
manager_note
```

Do not accept `expected_cash` from client.

## Phase 7 — Inventory Ledger Hardening

Use `stock_movements` as ledger source of truth.
Add tenant_id, reference fields, reason_code, approval context.

## Phase 8 — Cleanup

After app is fully migrated:
- Remove/hide legacy `users.role`, `users.permissions`, `users.outlet_id`.
- Remove stale functions.
- Drop conflicting global unique indexes after safe tenant-scoped replacements exist.
