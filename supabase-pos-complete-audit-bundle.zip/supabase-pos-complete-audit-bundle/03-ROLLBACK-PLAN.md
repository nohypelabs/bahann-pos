# Rollback Plan

## Principle

Every phase must be reversible until legacy fields are removed. No heroic production migration. Humans already invented enough unreliable things.

## Phase 0 rollback

If emergency RLS patch breaks app:
1. Do not disable RLS blindly in production.
2. Identify failed endpoint and missing policy.
3. Prefer service-role backend endpoint for sensitive tables.
4. As last resort in staging only, re-grant minimal SELECT/INSERT to authenticated and add restrictive policy.

## Tenant foundation rollback

Before adding NOT NULL:
- New `tenant_id` columns can remain nullable.
- App can keep using owner/outlet legacy model.
- Rollback app feature flag to legacy guard.

After adding NOT NULL:
- Keep backup migration.
- Validate row counts per tenant before rollback.

## RBAC rollback

Keep legacy fields during transition:
```txt
users.role
users.permissions
users.outlet_id
```

If RBAC guard fails:
- Disable RBAC feature flag.
- Fall back to legacy role/outlet guard.
- Do not drop assignment tables; fix data or permission mapping.

## POS device rollback

Keep outlet_id on shift/transaction. If device assignment fails:
- Use legacy outlet context in manager/admin screens only.
- Kasir POS should still not be allowed cross-outlet.

## Approval workflow rollback

Keep existing transaction void/refund fields. If approval table flow fails:
- Disable request queue feature.
- Allow admin-only direct void/refund temporarily.
- Preserve transaction_approvals rows for audit.

## Cleanup rollback warning

After dropping legacy fields, rollback becomes expensive. Do not drop legacy fields until:
- 2 full closing cycles pass.
- Refund/void tests pass.
- RLS tests pass.
- Global reports match legacy reports.
