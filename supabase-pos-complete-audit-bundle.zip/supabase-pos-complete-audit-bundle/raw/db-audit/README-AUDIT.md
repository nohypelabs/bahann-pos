# Supabase DB Audit Bundle

Generated at: 2026-06-17T10:45:00Z
Supabase CLI version: 2.51.0 (not used — direct psql audit)
psql version: 16.13 (PostgreSQL 17.6 server)
Project ref: skdgytedoilnlflyjvbc

## Files

| File | Description | Lines |
|------|-------------|-------|
| schema-public.sql | Table DDL (columns, types, defaults) | 346 |
| rls-status.txt | RLS enable/disable per table | 30 |
| policies.txt | All CREATE POLICY definitions | 29 |
| indexes.txt | All indexes (primary, unique, custom) | 114 |
| foreign-keys.txt | All foreign key constraints | 44 |
| constraints.txt | UNIQUE + CHECK constraints | 23 |
| triggers.txt | All triggers | 7 |
| functions.sql | Function DDL (CREATE OR REPLACE) | 363 |
| functions-raw.txt | Function metadata from information_schema | 164 |
| views.txt | View definitions | 18 |
| materialized-views.txt | Materialized views (if any) | 4 |
| grants.txt | Table-level grants/privileges | 760 |
| enums.txt | Custom enum types + values | 18 |
| extensions.txt | Installed PostgreSQL extensions | 10 |
| table-sizes.txt | Table sizes (total + table-only) | 30 |
| migrations.txt | Migration file listing (005–032) | 28 |
| database.types.ts | Generated TypeScript types (Supabase) | ~1000 |
| pgdump-error.txt | pg_dump skipped (v16 client vs v17 server) | 2 |

## Safety

- No database mutations were executed.
- No credentials are included.
- Secrets, if found, were redacted with `[REDACTED]`.
- pg_dump was skipped due to client/server version mismatch (psql-based extraction used instead).
- Supabase CLI `db dump` was skipped because no access token was configured.

## Schema Summary

- 26 tables in `public` schema
- 21 tables with RLS enabled, 5 without
- 12 RLS policies defined
- 4 custom enum types (business_type, item_type, pricing_model, stock_behavior)
- 3 triggers (all BEFORE UPDATE for updated_at)
- 1 view (stock_sales_monitor)
- 32 migrations (005–032)

## Tables WITHOUT RLS

- bank_accounts
- payment_confirmations
- payment_methods
- payments
- qris_config
- wa_templates

## Notes

- The database uses Supabase Auth (auth.uid()) in RLS policies.
- Most RLS policies scope by `owner_id` via outlets table (tenant isolation).
- Functions include: cleanup_expired_refresh_tokens, update_updated_at_column, and trigger helpers.
- No materialized views found.
