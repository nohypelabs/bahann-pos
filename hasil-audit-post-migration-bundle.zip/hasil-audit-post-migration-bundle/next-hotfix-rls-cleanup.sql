-- Next hotfix: cleanup stale permissive policies + safer audit/token posture.
-- Run in staging first. Review app flows before production.

BEGIN;

-- 1) Token tables should be backend-only.
DROP POLICY IF EXISTS "Backend can manage password reset tokens" ON public.password_reset_tokens;
DROP POLICY IF EXISTS "password_reset_tokens_deny_all" ON public.password_reset_tokens;
CREATE POLICY password_reset_tokens_deny_all
  ON public.password_reset_tokens
  FOR ALL
  TO public
  USING (false)
  WITH CHECK (false);

DROP POLICY IF EXISTS "System can insert refresh tokens" ON public.refresh_tokens;
DROP POLICY IF EXISTS "System can update refresh tokens" ON public.refresh_tokens;
DROP POLICY IF EXISTS "Users can delete own refresh tokens" ON public.refresh_tokens;
DROP POLICY IF EXISTS "Users can read own refresh tokens" ON public.refresh_tokens;
DROP POLICY IF EXISTS "refresh_tokens_deny_all" ON public.refresh_tokens;
CREATE POLICY refresh_tokens_deny_all
  ON public.refresh_tokens
  FOR ALL
  TO public
  USING (false)
  WITH CHECK (false);

REVOKE ALL ON public.password_reset_tokens FROM anon, authenticated;
REVOKE ALL ON public.refresh_tokens FROM anon, authenticated;

-- 2) Audit logs should not be insertable by anon.
DROP POLICY IF EXISTS "System can insert audit logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Admins can read all audit logs" ON public.audit_logs;
DROP POLICY IF EXISTS audit_logs_insert ON public.audit_logs;

REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON public.audit_logs FROM anon, authenticated;

-- Optional: uncomment only if authenticated clients must insert their own audit logs.
-- Prefer service-role/server-side logging instead.
-- CREATE POLICY audit_logs_insert_own_context
--   ON public.audit_logs
--   FOR INSERT
--   TO authenticated
--   WITH CHECK (
--     actor_user_id = auth.uid()
--     AND tenant_id IN (
--       SELECT ura.tenant_id
--       FROM public.user_role_assignments ura
--       WHERE ura.user_id = auth.uid()
--     )
--   );

-- 3) Payment method config should not be globally readable if account_details is sensitive.
-- Review your app first. If frontend needs public payment labels, create a safe view without account_details.
-- DROP POLICY IF EXISTS payment_methods_read_only ON public.payment_methods;
-- CREATE POLICY payment_methods_deny_all
--   ON public.payment_methods
--   FOR ALL
--   TO public
--   USING (false)
--   WITH CHECK (false);

COMMIT;
